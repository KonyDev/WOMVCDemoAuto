ALTER TABLE `Technician`
	ADD `Email` VARCHAR(50);
